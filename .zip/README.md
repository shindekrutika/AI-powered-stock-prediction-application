# AI Stock Predictor

An end-to-end application for predicting stock prices using AI. This application uses a React + Vite + TailwindCSS frontend and a FastAPI + Poetry backend with an LSTM model for stock prediction.

## Features

- **AI-Powered Predictions**: Get 7-day and 30-day stock price predictions using LSTM neural networks
- **Interactive Dashboard**: Search for stocks, view historical data, and see predictions in real-time
- **PDF Reports**: Generate and download detailed PDF reports of predictions
- **User Authentication**: Secure signup and login system
- **Prediction History**: View and manage past predictions
- **Dark/Light Theme**: Toggle between dark and light themes for better viewing experience

## Prerequisites

Before you begin, ensure you have the following installed:

### Required Software

1. **Node.js (v14 or higher)**

   - Download from [Node.js official website](https://nodejs.org/)
   - Verify installation: `node --version`

2. **Python (v3.8 or higher)**

   - Download from [Python official website](https://www.python.org/downloads/)
   - Verify installation: `python --version`

3. **Poetry (Python package manager)**

   - Installation instructions:

     ```bash
     # Windows (PowerShell)
     (Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | python -

     # macOS/Linux
     curl -sSL https://install.python-poetry.org | python3 -
     ```

   - Verify installation: `poetry --version`

4. **Docker (Optional, for containerized deployment)**
   - Download from [Docker official website](https://www.docker.com/get-started/)
   - Verify installation: `docker --version`

## Installation and Setup

### Option 1: Local Development Setup

1. **Clone the repository**:

   ```bash
   git clone https://github.com/yourusername/stock-predictor.git
   cd stock-predictor
   ```

2. **Install dependencies**:

   ```bash
   # Install all dependencies (both frontend and backend)
   npm run packages:install
   ```

3. **Start the development servers**:

   ```bash
   # This will start both frontend and backend concurrently
   npm run dev
   ```

   The application will be available at:

   - Frontend: http://localhost:5173
   - Backend API: http://localhost:8000

### Option 2: Docker Setup

1. **Build and run using Docker**:

   ```bash
   # Build the backend image
   cd backend
   docker build -t stock-predictor-backend .

   # Run the backend container
   docker run -p 8000:8000 stock-predictor-backend

   # In a new terminal, start the frontend
   cd frontend
   npm install
   npm run dev
   ```

## Project Structure

```
stock-predictor/
├── frontend/           # React + Vite + TailwindCSS frontend
│   ├── src/           # Source code
│   ├── public/        # Static assets
│   └── package.json   # Frontend dependencies
├── backend/           # FastAPI + Poetry backend
│   ├── app/          # Application code
│   ├── models/       # ML models
│   └── pyproject.toml # Backend dependencies
└── package.json      # Root project configuration
```

## Available Scripts

From the root directory:

- `npm run packages:install`: Install all dependencies (both frontend and backend)
- `npm run frontend:dev`: Start frontend development server
- `npm run backend:dev`: Start backend development server
- `npm run dev`: Start both frontend and backend concurrently
- `npm run frontend:build`: Build frontend for production

## Usage Guide

1. **Create an Account**

   - Navigate to http://localhost:5173/signup
   - Fill in your details and create an account

2. **Login**

   - Use your credentials to log in at http://localhost:5173/login

3. **Search for Stocks**

   - Enter a stock symbol (e.g., RELIANCE, TATASTEEL, INFY)
   - View historical data and predictions

4. **Generate Reports**

   - Click on a stock to view detailed information
   - Use the "Download Report" button to generate PDF reports

5. **View History**
   - Access your prediction history from the dashboard

## Troubleshooting

### Common Issues

1. **Port Conflicts**

   - If ports 5173 or 8000 are in use, you can change them:
     - Frontend: Edit `frontend/vite.config.ts`
     - Backend: Edit `backend/.env`

2. **Dependency Installation Issues**

   - Frontend: Try `npm cache clean --force` and reinstall
   - Backend: Try `poetry cache clear .` and reinstall

3. **Docker Issues**
   - Ensure Docker is running
   - Try `docker system prune` to clean up unused resources

## Development

### Frontend Development

```bash
cd frontend
npm run dev
```

### Backend Development

```bash
cd backend
poetry run run-app
```

## Tools & Technologies utilized

- [FastAPI](https://fastapi.tiangolo.com/)
- [React](https://reactjs.org/)
- [TailwindCSS](https://tailwindcss.com/)
- [yfinance](https://github.com/ranaroussi/yfinance)
- [PyTorch](https://pytorch.org/)
- [ReportLab](https://www.reportlab.com/)

## White Paper

# Stock Price Prediction Using LSTM Neural Networks: A Technical Overview

## 1. System Architecture

![System Architecture](images/paper-1.png)

### 1.1 High-Level Components
- Data Collection Layer (NSE Scraper)
- Model Training Layer (LSTM Neural Network)
- Prediction Service Layer (FastAPI Backend)

## 2. Data Collection and Preprocessing

### 2.1 NSE Stock Data Collection
The system collects data from India's National Stock Exchange (NSE) using the following approach:

```python
def get_nse_top_100():
    # Fallback list of top 20 NSE stocks
    return ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", ...]
```

Key features:
- Historical data retrieval using yfinance
- 5-year historical data window
- OHLCV (Open, High, Low, Close, Volume) data points

![NSE Stock Data Collection](images/paper-2.png)

### 2.2 Data Preprocessing
The preprocessing pipeline includes:
1. Time series normalization using MinMaxScaler
2. Sequence generation (60-day windows)
3. Feature scaling to range [0,1]

## 3. Neural Network Architecture

![LSTM Neural Network Architecture](images/paper-3.png)

### 3.1 LSTM Model Structure
```python
model = Sequential([
    LSTM(units=50, return_sequences=True, input_shape=(60, 1)),
    Dropout(0.2),
    LSTM(units=50, return_sequences=True),
    Dropout(0.2),
    LSTM(units=50),
    Dropout(0.2),
    Dense(units=2)
])
```

Key components:
- Input: 60-day sequence window
- 3 LSTM layers with 50 units each
- Dropout layers (0.2) for regularization
- Output: 2 units (7-day and 30-day predictions)

### 3.2 Model Training Process

![Model Training Process](images/paper-4.png)

Training parameters:
- Sequence length: 60 days
- Batch size: 32
- Epochs: 50
- Optimizer: Adam (learning_rate=0.001)
- Loss function: Mean Squared Error

## 4. Prediction Service

### 4.1 Real-time Prediction Pipeline
```python
def predict(symbol: str):
    recent_data = get_recent_data(symbol)
    predictions = model.predict(recent_data)
    return {
        "predicted_price_7d": predictions[0][0],
        "predicted_price_30d": predictions[0][1],
        "confidence_level": calculate_confidence()
    }
```

![Prediction Service](images/paper-5.png)

### 4.2 Confidence Calculation
The system calculates prediction confidence based on:
- Price range volatility
- Prediction stability
- Historical accuracy

## 5. Technical Implementation Details

### 5.1 Data Processing Pipeline
1. Historical data collection (5 years)
2. Sequence generation (60-day windows)
3. Feature scaling and normalization
4. Training data preparation

### 5.2 Model Architecture Details
- Input Layer: (None, 60, 1) - 60 timesteps, 1 feature
- LSTM Layers: 50 units each with return sequences
- Dropout Rate: 0.2 for regularization
- Dense Output: 2 units for dual predictions

![Model Architecture Details](images/paper-6.png)

## 6. Performance Metrics

### 6.1 Model Evaluation
- Mean Squared Error (MSE)
- Prediction accuracy percentage
- Confidence level distribution

![Model Evaluation](images/paper-7.png)

## 7. Trading Signals

The model generates trading signals based on:
```python
def generate_recommendation(current_price, pred_7d, pred_30d):
    if return_7d > 0.05 and return_30d > 0.1:
        return "BUY"
    elif return_7d < -0.05 and return_30d < -0.1:
        return "SELL"
    else:
        return "HOLD"
```
If 7 day returns are more than 0.05% and 30 day returns are more than 0.1% then BUY
If 7 day returns are less than -0.05% and 30 day returns are less than -0.1% then SELL
If none of the above condition satisfies then HOLD

## 8. Future Improvements

1. Enhanced Feature Engineering
   - Technical indicators integration
   - Sentiment analysis
   - Market indices correlation

2. Model Optimization
   - Hyperparameter tuning
   - Ensemble methods
   - Attention mechanisms

![Future Improvements](images/paper-8.png)

This white paper provides a comprehensive overview of the stock prediction system's technical implementation, focusing on the neural network architecture and data processing pipeline. The system combines modern deep learning techniques with traditional financial analysis to provide accurate stock price predictions.
