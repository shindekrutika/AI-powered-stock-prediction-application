# Stock Predictor Backend

The backend service for the Stock Predictor application built with FastAPI, Poetry, and machine learning models.

## Features

- RESTful API with FastAPI
- User authentication with JWT
- Stock data fetching with yfinance
- LSTM model for price predictions
- PDF report generation
- SQLAlchemy database integration

## Prerequisites

Before you begin, ensure you have the following installed:

- Python (v3.8 or higher)
- Poetry (Python package manager)
- Docker (optional, for containerized deployment)

## Installation

1. **Install dependencies**:

   ```bash
   # From the project root
   npm run backend:install

   # Or directly from the backend directory
   cd backend
   poetry install
   ```

2. **Environment Setup**:
   Create a `.env` file in the backend directory with:
   ```
   DATABASE_URL=sqlite:///./stock_predictor.db
   SECRET_KEY=your-secret-key
   ALGORITHM=HS256
   ACCESS_TOKEN_EXPIRE_MINUTES=30
   ```

## Development

1. **Start the development server**:

   ```bash
   # From the project root
   npm run backend:dev

   # Or directly from the backend directory
   cd backend
   poetry run run-app
   ```

2. **API Documentation**:
   - Swagger UI: http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc

## Project Structure

```
backend/
├── app/
│   ├── api/           # API endpoints
│   ├── core/          # Core functionality
│   ├── models/        # Database models
│   ├── schemas/       # Pydantic schemas
│   ├── services/      # Business logic
│   ├── utils/         # Utility functions
│   └── main.py        # Application entry point
├── models/            # ML models
├── tests/             # Test files
└── pyproject.toml     # Dependencies and configuration
```

## API Endpoints

### Authentication

- `POST /auth/register`: Register a new user
- `POST /auth/token`: Login and get access token
- `POST /auth/verify`: Verify access token

### Stocks

- `GET /stocks/history`: Get stock history
- `GET /stocks/predict`: Get stock predictions
- `POST /stocks/report`: Generate PDF report

### Users

- `GET /users/me`: Get current user info
- `GET /users/predictions`: Get user's predictions

## Development Guidelines

1. **Code Structure**

   - Follow FastAPI best practices
   - Use dependency injection
   - Keep routes clean and focused

2. **Database**

   - Use SQLAlchemy ORM
   - Follow migration best practices
   - Maintain data integrity

3. **Testing**

   - Write unit tests for services
   - Test API endpoints
   - Mock external services

4. **Security**
   - Use JWT for authentication
   - Implement rate limiting
   - Validate all inputs

## Testing

```bash
# Run tests
poetry run pytest

# Run tests with coverage
poetry run pytest --cov=app
```

## Docker Deployment

1. **Build the image**:

   ```bash
   docker build -t stock-predictor-backend .
   ```

2. **Run the container**:
   ```bash
   docker run -p 8000:8000 stock-predictor-backend
   ```

## Troubleshooting

1. **Dependency Issues**

   - Clear Poetry cache: `poetry cache clear .`
   - Update Poetry: `poetry self update`
   - Check Python version compatibility

2. **Database Issues**

   - Check database connection string
   - Verify migrations are applied
   - Check database permissions

3. **API Issues**
   - Check environment variables
   - Verify JWT configuration
   - Check API documentation

## Contributing

1. Create a feature branch
2. Make your changes
3. Run tests and linting
4. Submit a pull request

## License

This project is licensed under the MIT License.
