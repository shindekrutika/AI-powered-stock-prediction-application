import io
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import (Paragraph, SimpleDocTemplate, Spacer, Table,
                               TableStyle)
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.db.database import get_db
from app.models.prediction import StockPrediction
from app.models.user import User

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("/{prediction_id}/pdf")
async def generate_pdf_report(
    prediction_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate a PDF report for a specific prediction."""
    # Find the prediction
    prediction = db.query(StockPrediction).filter(
        StockPrediction.id == prediction_id,
        StockPrediction.user_id == current_user.id
    ).first()
    
    if not prediction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Prediction not found"
        )
    
    # Create PDF in memory
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []
    
    # Title
    title = f"Stock Prediction Report - {prediction.stock_symbol}"
    elements.append(Paragraph(title, styles["Heading1"]))
    elements.append(Spacer(1, 12))
    
    # Date
    date_str = prediction.created_at.strftime("%Y-%m-%d %H:%M:%S")
    elements.append(Paragraph(f"Generated on: {date_str}", styles["Normal"]))
    elements.append(Spacer(1, 12))
    
    # Prediction Summary
    elements.append(Paragraph("Prediction Summary", styles["Heading2"]))
    elements.append(Spacer(1, 6))
    
    data = [
        ["Stock Symbol", prediction.stock_symbol],
        ["Current Price", f"₹{prediction.current_price:.2f}"],
        ["7-Day Prediction", f"₹{prediction.predicted_price_7d:.2f}"],
        ["30-Day Prediction", f"₹{prediction.predicted_price_30d:.2f}"],
        ["Confidence Level", f"{prediction.confidence_level:.2%}"],
        ["Recommendation", prediction.recommendation]
    ]
    
    # Calculate 7-day and 30-day changes
    change_7d = ((prediction.predicted_price_7d - prediction.current_price) / 
                prediction.current_price) * 100
    change_30d = ((prediction.predicted_price_30d - prediction.current_price) / 
                 prediction.current_price) * 100
    
    data.append(["7-Day Change", f"{change_7d:.2f}%"])
    data.append(["30-Day Change", f"{change_30d:.2f}%"])
    
    # Create the table
    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.black),
        ('ALIGN', (0, 0), (0, -1), 'LEFT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(table)
    elements.append(Spacer(1, 12))
    
    # Recommendation explanation
    elements.append(Paragraph("Recommendation Explanation", styles["Heading2"]))
    elements.append(Spacer(1, 6))
    
    if prediction.recommendation == "Buy":
        explanation = (
            "The AI model predicts a positive trend for this stock in the upcoming period. "
            f"With a projected increase of {change_30d:.2f}% over the next 30 days, "
            "the system recommends buying this stock."
        )
    elif prediction.recommendation == "Sell":
        explanation = (
            "The AI model predicts a negative trend for this stock in the upcoming period. "
            f"With a projected decrease of {abs(change_30d):.2f}% over the next 30 days, "
            "the system recommends selling this stock."
        )
    else:  # Hold
        explanation = (
            "The AI model predicts a relatively stable price for this stock in the upcoming period. "
            f"With a projected change of {change_30d:.2f}% over the next 30 days, "
            "the system recommends holding this stock."
        )
    
    elements.append(Paragraph(explanation, styles["Normal"]))
    elements.append(Spacer(1, 12))
    
    # Disclaimer
    elements.append(Paragraph("Disclaimer", styles["Heading2"]))
    elements.append(Spacer(1, 6))
    disclaimer_text = (
        "This report is generated using an AI prediction model and should not be "
        "considered as financial advice. All investments involve risk, and past "
        "performance is not indicative of future results. Please consult with a "
        "qualified financial advisor before making investment decisions."
    )
    elements.append(Paragraph(disclaimer_text, styles["Normal"]))
    
    # Build the PDF
    doc.build(elements)
    buffer.seek(0)
    
    # Return the PDF as a streaming response
    return StreamingResponse(
        buffer, 
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment;filename={prediction.stock_symbol}_prediction_report.pdf"
        }
    ) 