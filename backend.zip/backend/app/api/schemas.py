from datetime import datetime
from typing import Optional

from pydantic import BaseModel


# User schemas
class UserBase(BaseModel):
    email: str
    username: str


class UserCreate(UserBase):
    password: str


class UserLogin(BaseModel):
    email: str
    password: str


class User(UserBase):
    id: int
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# Token schemas
class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    email: Optional[str] = None


# Stock prediction schemas
class StockPredictionCreate(BaseModel):
    stock_symbol: str


class StockPrediction(BaseModel):
    id: int
    stock_symbol: str
    current_price: float
    predicted_price_7d: float
    predicted_price_30d: float
    confidence_level: float
    recommendation: str
    created_at: datetime

    model_config = {"from_attributes": True} 