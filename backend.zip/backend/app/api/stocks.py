from typing import List
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import and_

from app.api import schemas
from app.api.auth import get_current_user
from app.db.database import get_db
# Old StockPredictor Model
# This was not trained on the data
# from app.ml.model import StockPredictor
from app.models.prediction import StockPrediction
from app.models.user import User
from app.services.stock_service import StockService
from app.services.prediction_service import PredictionService

router = APIRouter(
    prefix="/stocks",
    tags=["stocks"],
    responses={404: {"description": "Not found"}},
)

# Initialize stock predictor
# stock_predictor = StockPredictor()
# use prediction_service instead of stock_predictor
stock_predictor = PredictionService()


@router.post("/predict", response_model=schemas.StockPrediction)
async def predict_stock(
    stock_data: schemas.StockPredictionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Predict stock prices and save to database."""
    try:
        # Check for existing prediction within last 5 minutes
        five_minutes_ago = datetime.utcnow() - timedelta(minutes=5)
        existing_prediction = db.query(StockPrediction).filter(
            and_(
                StockPrediction.user_id == current_user.id,
                StockPrediction.stock_symbol == stock_data.stock_symbol,
            )
        ).first()

        if existing_prediction:
            # Return existing prediction without running the model again
            # Return the existing prediction if it's within 5 minutes
            if existing_prediction.created_at > five_minutes_ago and existing_prediction.updated_at > five_minutes_ago:
                prediction_results = stock_predictor.predict(stock_data.stock_symbol)
                existing_prediction.current_price = prediction_results["current_price"]
                existing_prediction.predicted_price_7d = prediction_results["predicted_price_7d"]
                existing_prediction.predicted_price_30d = prediction_results["predicted_price_30d"]
                existing_prediction.confidence_level = prediction_results["confidence_level"]
                existing_prediction.recommendation = prediction_results["recommendation"]
                existing_prediction.updated_at = datetime.utcnow()
                db.commit()
                db.refresh(existing_prediction)
                existing_prediction = db.query(StockPrediction).filter(
                    and_(
                        StockPrediction.user_id == current_user.id,
                        StockPrediction.stock_symbol == stock_data.stock_symbol,
                    )
                ).first()
            return existing_prediction

        # Create new prediction if none exists or if existing one is older than 5 minutes
        prediction_results = stock_predictor.predict(stock_data.stock_symbol)

        # Create prediction record
        db_prediction = StockPrediction(
            user_id=current_user.id,
            stock_symbol=stock_data.stock_symbol,
            current_price=prediction_results["current_price"],
            predicted_price_7d=prediction_results["predicted_price_7d"],
            predicted_price_30d=prediction_results["predicted_price_30d"],
            confidence_level=prediction_results["confidence_level"],
            recommendation=prediction_results["recommendation"]
        )

        db.add(db_prediction)
        db.commit()
        db.refresh(db_prediction)

        return db_prediction
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to predict stock: {str(e)}"
        )


@router.get("/history", response_model=List[schemas.StockPrediction])
async def get_prediction_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get prediction history for the current user."""
    predictions = db.query(StockPrediction).filter(
        StockPrediction.user_id == current_user.id
    ).order_by(StockPrediction.created_at.desc()).all()

    return predictions


@router.get("/{symbol}")
async def get_stock_data(symbol: str, period: str = "1y"):
    """
    Get stock data for a given NSE symbol
    Args:
        symbol: NSE stock symbol (e.g., "RELIANCE")
        period: Time period for data (e.g., "1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "ytd", "max")
    """
    try:
        return StockService.get_stock_data(symbol, period)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/info/{symbol}")
async def get_stock_info(symbol: str):
    """
    Get detailed information about a stock
    Args:
        symbol: NSE stock symbol (e.g., "RELIANCE")
    """
    try:
        return StockService.get_stock_info(symbol)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/multiple")
async def get_multiple_stocks(symbols: List[str], period: str = "1y"):
    """
    Get data for multiple NSE stocks
    Args:
        symbols: List of NSE stock symbols
        period: Time period for data
    """
    try:
        return StockService.get_multiple_stocks(symbols, period)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
