from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import auth, reports, stocks
from app.db.database import Base, engine
from app.settings import APP_URL

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Stock Predictor API",
    description="API for predicting stock prices using machine learning",
    version="0.1.0",
)

allowed_origin = APP_URL
# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[allowed_origin],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(stocks.router)
app.include_router(reports.router)


@app.get("/")
async def root():
    return {"message": "Welcome to the Stock Predictor API"}


@app.get("/health")
async def health_check():
    return {"status": "healthy"}
