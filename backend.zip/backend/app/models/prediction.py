from sqlalchemy import Column, Float, ForeignKey, Integer, String
from sqlalchemy.sql.sqltypes import DateTime
from sqlalchemy.sql import func

from app.db.database import Base


class StockPrediction(Base):
    __tablename__ = "stock_predictions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    stock_symbol = Column(String, index=True)
    current_price = Column(Float)
    predicted_price_7d = Column(Float)
    predicted_price_30d = Column(Float)
    confidence_level = Column(Float)  # 0-1 scale
    recommendation = Column(String)  # Buy, Hold, Sell
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True),
                        server_default=func.now(), onupdate=func.now())
