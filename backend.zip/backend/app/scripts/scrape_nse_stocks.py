import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import logging
from typing import List, Dict
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def get_nse_top_100() -> List[str]:
    """
    Scrape the top 100 NSE stocks from NSE website
    Returns:
        List of stock symbols
    """
    try:
        # URL for NSE top 100 stocks
        raise "This will not work as the NSE website has changed its structure"
        url = "https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%20100"

        # Use pandas to read the JSON data
        df = pd.read_json(url)

        # Extract symbols and add .NS suffix
        symbols = [f"{symbol}.NS" for symbol in df['symbol'].tolist()]

        logger.info(f"Successfully fetched {len(symbols)} NSE stocks")
        return symbols
    except Exception as e:
        logger.error(f"Error fetching NSE stocks: {str(e)}")
        # Fallback to a predefined list of top NSE stocks
        return [
            "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
            "HINDUNILVR.NS", "SBIN.NS", "BHARTIARTL.NS", "KOTAKBANK.NS", "BAJFINANCE.NS",
            "WIPRO.NS", "ONGC.NS", "HCLTECH.NS", "AXISBANK.NS", "TATAMOTORS.NS",
            "NESTLEIND.NS", "ULTRACEMCO.NS", "SUNPHARMA.NS", "TITAN.NS", "ADANIPORTS.NS"
        ]


def fetch_stock_data(symbol: str, start_date: str, end_date: str) -> Dict:
    """
    Fetch historical data for a stock
    Args:
        symbol: Stock symbol with .NS suffix
        start_date: Start date in YYYY-MM-DD format
        end_date: End date in YYYY-MM-DD format
    Returns:
        Dictionary containing stock data
    """
    try:
        stock = yf.Ticker(symbol)
        hist = stock.history(start=start_date, end=end_date)

        if hist.empty:
            logger.warning(f"No data found for {symbol}")
            return None

        # Convert DataFrame to dictionary and format dates
        data = []
        for index, row in hist.reset_index().iterrows():
            data.append({
                'Date': row['Date'].strftime('%Y-%m-%d'),
                'Open': float(row['Open']),
                'High': float(row['High']),
                'Low': float(row['Low']),
                'Close': float(row['Close']),
                'Volume': int(row['Volume'])
            })

        return {
            "symbol": symbol,
            "data": data
        }
    except Exception as e:
        logger.error(f"Error fetching data for {symbol}: {str(e)}")
        return None


def main():
    # Get date range (last 1 year)
    end_date = datetime.now()
    year = 365
    difference = timedelta(days=(year * 5))
    start_date = end_date - difference

    # Format dates
    start_date_str = start_date.strftime("%Y-%m-%d")
    end_date_str = end_date.strftime("%Y-%m-%d")

    print(f"Scrapping data between {start_date_str} and {end_date_str}")

    # Get top 100 NSE stocks
    symbols = get_nse_top_100()

    print(f"Fetching data for {len(symbols)} stocks")

    # Fetch data for each stock
    stock_data = []
    for symbol in symbols:
        logger.info(f"Fetching data for {symbol}")
        data = fetch_stock_data(symbol, start_date_str, end_date_str)
        if data:
            stock_data.append(data)
        time.sleep(1)  # Add delay to avoid rate limiting

    # Save data to a file
    import json
    with open("nse_stock_data.json", "w") as f:
        json.dump(stock_data, f)

    logger.info(f"Successfully saved data for {len(stock_data)} stocks")


if __name__ == "__main__":
    main()
