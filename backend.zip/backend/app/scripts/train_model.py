import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.optimizers import Adam
import logging
from typing import List, Dict, Tuple
import joblib
import os
import tensorflow as tf

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class StockPredictor:
    def __init__(self, sequence_length: int = 60):
        logger.info(
            f"Initializing StockPredictor with sequence_length={sequence_length}")
        self.sequence_length = sequence_length
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.model = self._build_model()

    def _build_model(self) -> Sequential:
        """Build the LSTM model"""
        logger.info("Building LSTM model architecture...")
        model = Sequential([
            LSTM(units=50, return_sequences=True,
                 input_shape=(self.sequence_length, 1)),
            Dropout(0.2),
            LSTM(units=50, return_sequences=True),
            Dropout(0.2),
            LSTM(units=50),
            Dropout(0.2),
            Dense(units=2)  # Predict 7-day and 30-day prices
        ])

        model.compile(optimizer=Adam(learning_rate=0.001),
                      loss='mean_squared_error')
        logger.info("Model architecture built and compiled successfully")
        return model

    def prepare_data(self, data: List[Dict]) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare data for training"""
        logger.info("Starting data preparation...")
        X, y = [], []
        total_stocks = len(data)
        processed_stocks = 0

        for stock in data:
            processed_stocks += 1
            logger.info(
                f"Processing stock {processed_stocks}/{total_stocks}: {stock.get('symbol', 'Unknown')}")

            df = pd.DataFrame(stock['data'])
            if len(df) < self.sequence_length + 30:
                logger.warning(
                    f"Skipping stock {stock.get('symbol', 'Unknown')} - insufficient data points")
                continue

            # Use only closing prices
            prices = df['Close'].values.reshape(-1, 1)
            scaled_prices = self.scaler.fit_transform(prices)
            logger.info(
                f"Scaled prices for {stock.get('symbol', 'Unknown')} - shape: {scaled_prices.shape}")

            # Create sequences
            sequences_created = 0
            for i in range(len(scaled_prices) - self.sequence_length - 30):
                X.append(scaled_prices[i:(i + self.sequence_length)])
                y.append([
                    scaled_prices[i + self.sequence_length + 6],  # 7-day price
                    # 30-day price
                    scaled_prices[i + self.sequence_length + 29]
                ])
                sequences_created += 1

            logger.info(
                f"Created {sequences_created} sequences for {stock.get('symbol', 'Unknown')}")

        X_array = np.array(X)
        y_array = np.array(y)
        logger.info(
            f"Data preparation complete. Final shapes - X: {X_array.shape}, y: {y_array.shape}")
        return X_array, y_array

    def train(self, X: np.ndarray, y: np.ndarray, epochs: int = 50, batch_size: int = 32):
        """Train the model"""
        logger.info(
            f"Starting model training with {epochs} epochs and batch_size={batch_size}")
        logger.info(f"Training data shapes - X: {X.shape}, y: {y.shape}")

        history = self.model.fit(
            X, y,
            epochs=epochs,
            batch_size=batch_size,
            verbose=1,
            callbacks=[
                tf.keras.callbacks.LambdaCallback(
                    on_epoch_end=lambda epoch, logs: logger.info(
                        f"Epoch {epoch + 1}/{epochs} - loss: {logs['loss']:.4f}"
                    )
                )
            ]
        )

        logger.info("Model training completed successfully")
        return history

    def save(self, model_path: str = "stock_predictor_model.h5", scaler_path: str = "stock_scaler.pkl"):
        """Save the model and scaler"""
        logger.info(f"Saving model to {model_path}")
        self.model.save(model_path)
        logger.info(f"Saving scaler to {scaler_path}")
        joblib.dump(self.scaler, scaler_path)
        logger.info("Model and scaler saved successfully")


def main():
    logger.info("Starting model training process...")

    # Load the scraped data
    try:
        logger.info("Loading stock data from nse_stock_data.json")
        with open("nse_stock_data.json", "r") as f:
            stock_data = json.load(f)
        logger.info(f"Successfully loaded data for {len(stock_data)} stocks")
    except FileNotFoundError:
        logger.error(
            "Stock data file not found. Please run scrape_nse_stocks.py first.")
        return
    except Exception as e:
        logger.error(f"Error loading stock data: {str(e)}")
        return

    # Initialize and train the model
    logger.info("Initializing StockPredictor")
    predictor = StockPredictor()

    logger.info("Preparing training data")
    X, y = predictor.prepare_data(stock_data)

    if len(X) == 0:
        logger.error("Not enough data to train the model")
        return

    logger.info(f"Starting model training with {len(X)} sequences")
    predictor.train(X, y)

    # Save the model
    model_dir = "models"
    os.makedirs(model_dir, exist_ok=True)
    logger.info(f"Creating model directory at {model_dir}")

    model_path = os.path.join(model_dir, "stock_predictor_model.h5")
    scaler_path = os.path.join(model_dir, "stock_scaler.pkl")

    predictor.save(model_path, scaler_path)
    logger.info("Model training process completed successfully")


if __name__ == "__main__":
    main()
