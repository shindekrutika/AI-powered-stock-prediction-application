import uvicorn
import logging

HOST = "0.0.0.0"  # Allow external connections
PORT = 8000
ENV = "Development"  # Change to "Production" for production environment

LOG_LEVEL = logging.DEBUG if ENV == "Development" else logging.INFO

LOGGER = logging.getLogger(__name__)


def run_dev_server(host: str = HOST, port: int = PORT) -> None:
    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        reload=True,
        log_level=LOG_LEVEL
    )


if __name__ == "__main__":
    run_dev_server(host=HOST, port=PORT)
