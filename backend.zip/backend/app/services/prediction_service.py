import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
import joblib
import yfinance as yf
from datetime import datetime, timedelta
import logging
from typing import Dict, Tuple
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PredictionService:
    def __init__(self):
        self.sequence_length = 60
        self.model = None
        self.scaler = None
        self.load_model()

    def load_model(self):
        """Load the trained model and scaler"""
        try:
            model_path = os.path.join(os.path.dirname(
                __file__), "..", "..", "models", "stock_predictor_model.h5")
            scaler_path = os.path.join(os.path.dirname(
                __file__), "..", "..", "models", "stock_scaler.pkl")

            if not os.path.exists(model_path) or not os.path.exists(scaler_path):
                raise FileNotFoundError("Model or scaler files not found")

            self.model = load_model(model_path)
            self.scaler = joblib.load(scaler_path)
            logger.info("Model and scaler loaded successfully")
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            raise

    def get_recent_data(self, symbol: str) -> np.ndarray:
        """Get recent stock data for prediction"""
        try:
            # Add .NS suffix if not present for NSE stocks
            if not symbol.endswith('.NS'):
                symbol = f"{symbol}.NS"

            stock = yf.Ticker(symbol)
            end_date = datetime.now()
            start_date = end_date - timedelta(days=self.sequence_length + 30)
            formatted_start_date = start_date.strftime("%Y-%m-%d")
            formatted_end_date = end_date.strftime("%Y-%m-%d")
            logger.info(
                f"Fetching data for {symbol} from {formatted_start_date} to {formatted_end_date}")

            hist = stock.history(start=formatted_start_date,
                                 end=formatted_end_date)
            if hist.empty:
                raise ValueError(f"No data found for {symbol}")

            # Use only closing prices
            prices = hist['Close'].values.reshape(-1, 1)

            if self.scaler is None:
                raise ValueError("Scaler not initialized")

            scaled_prices = self.scaler.transform(prices)

            # Get the most recent sequence
            recent_sequence = scaled_prices[-self.sequence_length:]
            return recent_sequence.reshape(1, self.sequence_length, 1)
        except Exception as e:
            logger.error(f"Error getting recent data: {str(e)}")
            raise

    def predict(self, symbol: str) -> Dict:
        """Make predictions for a stock"""
        try:
            if self.model is None or self.scaler is None:
                raise ValueError("Model or scaler not initialized")

            # Get recent data
            recent_data = self.get_recent_data(symbol)

            # Make prediction
            predictions = self.model.predict(recent_data)

            # Inverse transform predictions
            predictions = self.scaler.inverse_transform(predictions)

            nse_symbol = symbol
            if not nse_symbol.endswith('.NS'):
                nse_symbol = f"{nse_symbol}.NS"

            # Get current price
            current_price = yf.Ticker(nse_symbol).history(
                period="1d")['Close'].iloc[-1]
            if current_price is None:
                raise ValueError("Current price not found")
            current_price = float(current_price)

            # Calculate confidence level (based on prediction stability)
            confidence = self._calculate_confidence(
                predictions[0], current_price)

            # Generate recommendation
            recommendation = self._generate_recommendation(
                current_price,
                predictions[0][0],  # 7-day prediction
                predictions[0][1]   # 30-day prediction
            )

            return {
                "current_price": current_price,
                "predicted_price_7d": predictions[0][0],
                "predicted_price_30d": predictions[0][1],
                "confidence_level": confidence,
                "recommendation": recommendation
            }
        except Exception as e:
            logger.error(f"Error making prediction: {str(e)}")
            raise

    def _calculate_confidence(self, predictions: np.ndarray, current_price: float) -> float:
        """Calculate confidence level based on prediction stability"""
        # Simple confidence calculation based on prediction consistency
        price_range = max(predictions) - min(predictions)
        volatility = price_range / current_price

        # Higher confidence for more stable predictions
        confidence = 1.0 - min(volatility, 0.5)
        return max(min(confidence, 1.0), 0.0)

    def _generate_recommendation(self, current_price: float, pred_7d: float, pred_30d: float) -> str:
        """Generate buy/sell/hold recommendation"""
        # Calculate expected returns
        return_7d = (pred_7d - current_price) / current_price
        return_30d = (pred_30d - current_price) / current_price

        # Generate recommendation based on returns
        if return_7d > 0.05 and return_30d > 0.1:  # Strong positive returns
            return "BUY"
        elif return_7d < -0.05 and return_30d < -0.1:  # Strong negative returns
            return "SELL"
        else:
            return "HOLD"
