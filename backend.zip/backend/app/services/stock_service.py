import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Optional


class StockService:
    @staticmethod
    def get_stock_data(symbol: str, period: str = "1y") -> Dict:
        """
        Get stock data for a given NSE symbol
        Args:
            symbol: NSE stock symbol (e.g., "RELIANCE")
            period: Time period for data (e.g., "1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "ytd", "max")
        Returns:
            Dictionary containing stock data
        """
        try:
            # Add .NS suffix if not present
            if not symbol.endswith('.NS'):
                symbol = f"{symbol}.NS"

            stock = yf.Ticker(symbol)
            hist = stock.history(period=period)

            # Convert to dictionary format
            data = {
                "symbol": symbol,
                "current_price": hist['Close'].iloc[-1],
                "previous_close": hist['Close'].iloc[-2],
                "change": hist['Close'].iloc[-1] - hist['Close'].iloc[-2],
                "change_percent": ((hist['Close'].iloc[-1] - hist['Close'].iloc[-2]) / hist['Close'].iloc[-2]) * 100,
                "historical_data": hist.reset_index().to_dict('records')
            }

            return data
        except Exception as e:
            raise Exception(f"Error fetching stock data: {str(e)}")

    @staticmethod
    def get_multiple_stocks(symbols: List[str], period: str = "1y") -> Dict:
        """
        Get data for multiple NSE stocks
        Args:
            symbols: List of NSE stock symbols
            period: Time period for data
        Returns:
            Dictionary containing data for all stocks
        """
        result = {}
        for symbol in symbols:
            try:
                result[symbol] = StockService.get_stock_data(symbol, period)
            except Exception as e:
                result[symbol] = {"error": str(e)}
        return result

    @staticmethod
    def get_stock_info(symbol: str) -> Dict:
        """
        Get detailed information about a stock
        Args:
            symbol: NSE stock symbol
        Returns:
            Dictionary containing stock information
        """
        try:
            if not symbol.endswith('.NS'):
                symbol = f"{symbol}.NS"

            stock = yf.Ticker(symbol)
            info = stock.info

            return {
                "symbol": symbol,
                "name": info.get('longName', ''),
                "sector": info.get('sector', ''),
                "industry": info.get('industry', ''),
                "market_cap": info.get('marketCap', 0),
                "pe_ratio": info.get('trailingPE', 0),
                "dividend_yield": info.get('dividendYield', 0),
                "52_week_high": info.get('fiftyTwoWeekHigh', 0),
                "52_week_low": info.get('fiftyTwoWeekLow', 0),
                "currency": "INR"  # Explicitly set currency to INR
            }
        except Exception as e:
            raise Exception(f"Error fetching stock info: {str(e)}")
