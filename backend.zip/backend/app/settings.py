# load dotenv
from dotenv import load_dotenv
import os
load_dotenv(".env")


# Load environment variables
APP_URL = os.getenv("APP_URL")

SECRET_KEY = os.getenv('SECRET_KEY')
if SECRET_KEY == "":
    raise ValueError("SECRET_KEY not set in environment variables")
