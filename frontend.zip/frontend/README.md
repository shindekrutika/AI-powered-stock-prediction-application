# Stock Predictor Frontend

The frontend of the Stock Predictor application built with React, TypeScript, Vite, and TailwindCSS.

## Features

- Modern, responsive UI with dark/light theme support
- Interactive stock charts using Recharts
- Real-time stock data visualization
- User authentication and authorization
- PDF report generation
- Mobile-friendly design

## Prerequisites

Before you begin, ensure you have the following installed:

- Node.js (v14 or higher)
- npm (comes with Node.js)

## Installation

1. **Install dependencies**:

   ```bash
   # From the project root
   npm run frontend:install

   # Or directly from the frontend directory
   cd frontend
   npm install
   ```

2. **Environment Setup**:
   Create a `.env` file in the frontend directory with:
   ```
   VITE_API_URL=http://localhost:8000
   ```

## Development

1. **Start the development server**:

   ```bash
   # From the project root
   npm run frontend:dev

   # Or directly from the frontend directory
   cd frontend
   npm run dev
   ```

2. **Build for production**:

   ```bash
   # From the project root
   npm run frontend:build

   # Or directly from the frontend directory
   cd frontend
   npm run build
   ```

## Project Structure

```
frontend/
├── src/
│   ├── components/     # Reusable UI components
│   ├── pages/         # Page components
│   ├── hooks/         # Custom React hooks
│   ├── services/      # API services
│   ├── types/         # TypeScript type definitions
│   ├── utils/         # Utility functions
│   ├── App.tsx        # Main application component
│   └── main.tsx       # Application entry point
├── public/            # Static assets
└── package.json       # Dependencies and scripts
```

## Available Scripts

- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm run preview`: Preview production build
- `npm run lint`: Run ESLint
- `npm run type-check`: Run TypeScript type checking

## Development Guidelines

1. **Component Structure**

   - Use functional components with TypeScript
   - Follow the atomic design pattern
   - Keep components small and focused

2. **State Management**

   - Use React hooks for local state
   - Use React Query for server state
   - Keep global state minimal

3. **Styling**

   - Use TailwindCSS for styling
   - Follow mobile-first approach
   - Maintain consistent spacing and typography

4. **TypeScript**
   - Define types for all props and state
   - Use interfaces for component props
   - Avoid using `any` type

## Testing

```bash
# Run tests
npm run test

# Run tests in watch mode
npm run test:watch
```

## Troubleshooting

1. **Build Issues**

   - Clear npm cache: `npm cache clean --force`
   - Delete node_modules and reinstall
   - Check TypeScript errors

2. **Development Server Issues**

   - Check port conflicts (default: 5173)
   - Verify environment variables
   - Check network connectivity

3. **Dependency Issues**
   - Update npm: `npm install -g npm@latest`
   - Check package versions
   - Resolve peer dependency conflicts

## Contributing

1. Create a feature branch
2. Make your changes
3. Run tests and linting
4. Submit a pull request

## License

This project is licensed under the MIT License.
