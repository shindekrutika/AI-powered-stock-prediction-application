import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Prediction {
  id: number;
  stock_symbol: string;
  current_price: number;
  predicted_price_7d: number;
  predicted_price_30d: number;
  confidence_level: number;
  recommendation: string;
  created_at: string;
}

interface HistoryTableProps {
  predictionHistory: Prediction[];
  formatCurrency: (value: number) => string;
}

export default function HistoryTable({
  predictionHistory,
  formatCurrency,
}: HistoryTableProps) {
  const getRecommendationClass = (recommendation: string) => {
    switch (recommendation.toLowerCase()) {
      case "buy":
        return "text-green-500";
      case "sell":
        return "text-red-500";
      default:
        return "text-yellow-500";
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  return (
    <Card className="bg-card-gradient backdrop-blur-sm border-white/10">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold">Recent Predictions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-muted-foreground">Date</TableHead>
                <TableHead className="text-muted-foreground">Stock</TableHead>
                <TableHead className="text-muted-foreground">
                  Current Price
                </TableHead>
                <TableHead className="text-muted-foreground">
                  7-Day Forecast
                </TableHead>
                <TableHead className="text-muted-foreground">
                  30-Day Forecast
                </TableHead>
                <TableHead className="text-muted-foreground">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {predictionHistory.map((prediction) => (
                <TableRow
                  key={prediction.id}
                  className="hover:bg-secondary/20 transition-colors"
                >
                  <TableCell>{formatDate(prediction.created_at)}</TableCell>
                  <TableCell className="font-medium">
                    {prediction.stock_symbol}
                  </TableCell>
                  <TableCell>
                    {formatCurrency(prediction.current_price)}
                  </TableCell>
                  <TableCell>
                    {formatCurrency(prediction.predicted_price_7d)}
                  </TableCell>
                  <TableCell>
                    {formatCurrency(prediction.predicted_price_30d)}
                  </TableCell>
                  <TableCell
                    className={getRecommendationClass(
                      prediction.recommendation
                    )}
                  >
                    {prediction.recommendation}
                  </TableCell>
                </TableRow>
              ))}
              {predictionHistory.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="text-center py-6 text-muted-foreground"
                  >
                    No prediction history available. Search for a stock to get
                    started.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
