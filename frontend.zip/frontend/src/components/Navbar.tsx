import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChartArea, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Check if user is logged in
  const isLoggedIn = localStorage.getItem("token") !== null;
  const isHomePage = location.pathname === "/";

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.href = "/login";
  };

  return (
    <nav
      className={`py-4 px-6 lg:px-12 w-full ${
        isHomePage
          ? "absolute top-0 z-50"
          : "bg-background border-b border-border"
      }`}
    >
      <div className="container mx-auto">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <ChartArea className="text-white" size={24} />
            </div>
            <span className="text-xl font-bold text-white">
              TrendWhisperer<span className="text-primary">AI</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {location.pathname === "/" && (
              <div className="flex gap-6">
                <Link to="/" className="navbar-link">
                  Home
                </Link>
                <a href="#features" className="navbar-link">
                  Features
                </a>
              </div>
            )}

            {isLoggedIn ? (
              <div className="flex gap-4">
                <Button
                  className={cn(location.pathname === "/" && "hidden")}
                  onClick={handleLogout}
                >
                  Logout
                </Button>
                <Button
                  className={cn(location.pathname === "/dashboard" && "hidden")}
                  onClick={() => navigate("/dashboard")}
                >
                  Dashboard
                </Button>
              </div>
            ) : (
              <div className="flex gap-4">
                <Button variant="ghost" onClick={() => navigate("/login")}>
                  Login
                </Button>
                <Button onClick={() => navigate("/signup")}>Sign Up</Button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden text-foreground focus:outline-none"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-border animate-fade-in">
            <div className="flex flex-col gap-4">
              <Link
                to="/"
                className="navbar-link py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              {isLoggedIn && (
                <Link
                  to="/dashboard"
                  className="navbar-link py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Dashboard
                </Link>
              )}
              <a
                href="#features"
                className="navbar-link py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Features
              </a>
              <a
                href="#resources"
                className="navbar-link py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Resources
              </a>

              {isLoggedIn ? (
                <div className="flex flex-col gap-2 mt-2">
                  <Button variant="outline" onClick={handleLogout}>
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col gap-2 mt-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      navigate("/login");
                      setIsMenuOpen(false);
                    }}
                  >
                    Login
                  </Button>
                  <Button
                    onClick={() => {
                      navigate("/signup");
                      setIsMenuOpen(false);
                    }}
                  >
                    Sign Up
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
