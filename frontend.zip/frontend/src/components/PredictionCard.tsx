import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowDownRight, ArrowUpRight, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Prediction {
  id: number;
  stock_symbol: string;
  current_price: number;
  predicted_price_7d: number;
  predicted_price_30d: number;
  confidence_level: number;
  recommendation: string;
  created_at: string;
}

interface PredictionCardProps {
  prediction: Prediction;
  formatCurrency: (value: number) => string;
}

export default function PredictionCard({
  prediction,
  formatCurrency,
}: PredictionCardProps) {
  const getRecommendationClass = (recommendation: string) => {
    switch (recommendation.toLowerCase()) {
      case "buy":
        return "text-green-500";
      case "sell":
        return "text-red-500";
      default:
        return "text-yellow-500";
    }
  };

  const sevenDayChange =
    ((prediction.predicted_price_7d - prediction.current_price) /
      prediction.current_price) *
    100;
  const thirtyDayChange =
    ((prediction.predicted_price_30d - prediction.current_price) /
      prediction.current_price) *
    100;

  return (
    <Card className="bg-card-gradient backdrop-blur-sm border-white/10">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold">
          AI Prediction Results
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-x-6 gap-y-4">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Current Price</p>
            <p className="text-2xl font-bold">
              {formatCurrency(prediction.current_price)}
            </p>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-1">
              7-Day Prediction
            </p>
            <p className="text-2xl font-bold">
              {formatCurrency(prediction.predicted_price_7d)}
            </p>
            <div className="flex items-center">
              {sevenDayChange > 0 ? (
                <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
              ) : (
                <ArrowDownRight className="h-4 w-4 text-red-500 mr-1" />
              )}
              <p
                className={`text-sm ${
                  sevenDayChange > 0 ? "text-green-500" : "text-red-500"
                }`}
              >
                {sevenDayChange.toFixed(2)}% change
              </p>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-1">
              30-Day Prediction
            </p>
            <p className="text-2xl font-bold">
              {formatCurrency(prediction.predicted_price_30d)}
            </p>
            <div className="flex items-center">
              {thirtyDayChange > 0 ? (
                <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
              ) : (
                <ArrowDownRight className="h-4 w-4 text-red-500 mr-1" />
              )}
              <p
                className={`text-sm ${
                  thirtyDayChange > 0 ? "text-green-500" : "text-red-500"
                }`}
              >
                {thirtyDayChange.toFixed(2)}% change
              </p>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-1">
              AI Recommendation
            </p>
            <p
              className={`text-2xl font-bold ${getRecommendationClass(
                prediction.recommendation
              )}`}
            >
              {prediction.recommendation}
            </p>
            <div className="flex items-center">
              <div className="w-full bg-secondary rounded-full h-1.5 mt-1 mb-1">
                <div
                  className={`h-1.5 rounded-full ${
                    prediction.recommendation.toLowerCase() === "buy"
                      ? "bg-green-500"
                      : prediction.recommendation.toLowerCase() === "sell"
                      ? "bg-red-500"
                      : "bg-yellow-500"
                  }`}
                  style={{ width: `${prediction.confidence_level * 100}%` }}
                ></div>
              </div>
            </div>
            <p className="text-sm text-gray-400">
              Confidence: {(prediction.confidence_level * 100).toFixed(0)}%
            </p>
          </div>
        </div>

        <div className="mt-6">
          <Button
            className="w-full flex items-center justify-center gap-2"
            variant="outline"
          >
            <Download size={16} />
            Download Report as PDF
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
