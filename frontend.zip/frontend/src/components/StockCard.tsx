import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface CompanyInfo {
  symbol: string;
  name: string;
  sector: string;
  industry: string;
  market_cap: number;
  pe_ratio: number;
  dividend_yield: number;
}

interface StockCardProps {
  companyInfo: CompanyInfo;
  formatCurrency: (value: number) => string;
}

export default function StockCard({
  companyInfo,
  formatCurrency,
}: StockCardProps) {
  return (
    <Card className="bg-card-gradient backdrop-blur-sm border-white/10">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold flex flex-col md:flex-row md:items-center md:justify-between">
          <span>{companyInfo.name}</span>
          <span className="text-primary text-lg font-normal">
            {companyInfo.symbol}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Sector</p>
            <p className="font-medium">{companyInfo.sector}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Industry</p>
            <p className="font-medium">{companyInfo.industry}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Market Cap</p>
            <p className="font-medium">
              {formatCurrency(companyInfo.market_cap)}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">P/E Ratio</p>
            <p className="font-medium">{companyInfo.pe_ratio.toFixed(2)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Dividend Yield</p>
            <p className="font-medium">
              {companyInfo.dividend_yield.toFixed(2)}%
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
