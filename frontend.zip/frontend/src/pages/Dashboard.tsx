import { useState, useEffect } from "react";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import Navbar from "@/components/Navbar";
import { Search } from "lucide-react";

interface StockData {
  date: string;
  close: number;
}

interface CompanyInfo {
  symbol: string;
  name: string;
  sector: string;
  industry: string;
  market_cap: number;
  pe_ratio: number;
  dividend_yield: number;
}

interface Prediction {
  id: number;
  stock_symbol: string;
  current_price: number;
  predicted_price_7d: number;
  predicted_price_30d: number;
  confidence_level: number;
  recommendation: string;
  created_at: string;
}

const API_URL = import.meta.env.VITE_BACKEND_URL;
if (!API_URL) {
  throw new Error("VITE_BACKEND_URL is not defined");
}

const Dashboard = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [stockData, setStockData] = useState<StockData[]>([]);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [predictionHistory, setPredictionHistory] = useState<Prediction[]>([]);

  useEffect(() => {
    fetchPredictionHistory();
  }, []);

  const fetchPredictionHistory = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const response = await axios.get(`${API_URL}/stocks/history`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setPredictionHistory(response.data);
    } catch (err) {
      console.error("Error fetching prediction history:", err);
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError("");
    setPrediction(null);
    setCompanyInfo(null);
    setStockData([]);

    try {
      const dataResponse = await axios.get(`${API_URL}/stocks/${searchQuery}`);
      const stockData = dataResponse.data;

      setStockData(
        stockData.historical_data.map((item) => ({
          date: item.Date,
          close: item.Close,
        }))
      );

      const infoResponse = await axios.get(
        `${API_URL}/stocks/info/${searchQuery}`
      );
      setCompanyInfo(infoResponse.data);

      const token = localStorage.getItem("token");
      if (!token) {
        setError("You must be logged in to make predictions");
        setLoading(false);
        return;
      }

      const predictionResponse = await axios.post(
        `${API_URL}/stocks/predict`,
        { stock_symbol: searchQuery },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setPrediction(predictionResponse.data);
      fetchPredictionHistory();
    } catch (err) {
      if (axios.isAxiosError(err) && err.response) {
        setError(err.response.data.detail || "Error fetching stock data");
      } else {
        setError("An error occurred while fetching data. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  const getRecommendationClass = (recommendation: string) => {
    switch (recommendation.toLowerCase()) {
      case "buy":
        return "text-green-500";
      case "sell":
        return "text-red-500";
      default:
        return "text-yellow-500";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <div className="flex-1 container mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Stock Analytics Dashboard</h1>
          <p className="text-muted-foreground">
            Search for stocks and view AI-powered predictions
          </p>
        </div>

        <div className="max-w-7xl mx-auto">
        {/* Search Section */}
        <div className="mb-8">
          <form onSubmit={handleSearch} className="flex gap-4">
              <Input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Enter stock symbol (e.g., RELIANCE, TATASTEEL, INFY)"
                className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            <Button
              type="submit"
              disabled={loading}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
            >
              {loading ? "Searching..." : "Search"}
            </Button>
          </form>
        </div>

          {error && (
            <div className="mb-6 p-4 bg-red-900/50 border border-red-500 rounded-lg text-red-200">
              {error}
            </div>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-16 h-16 rounded-full border-4 border-primary/30 border-t-primary animate-spin mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Loading Stock Data</h3>
              <p className="text-muted-foreground text-center max-w-md">
                Retrieving information and generating AI predictions...
              </p>
            </div>
          )}

          {!companyInfo && !loading && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
                <Search className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Search for a Stock</h3>
              <p className="text-muted-foreground text-center max-w-md">
                Enter a stock symbol in the search bar to view detailed
                information, price history, and AI predictions.
              </p>
            </div>
          )}

          {/* Stock Info and Chart Section */}
        {companyInfo && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Company Info Card */}
            <div className="lg:col-span-1">
                <div className="bg-gray-800 rounded-lg p-6 h-full">
                  <h2 className="text-2xl font-bold mb-2">
                    {companyInfo.name}
                  </h2>
                  <p className="text-gray-400 mb-4">{companyInfo.symbol}</p>
                  <div className="space-y-4">
                    <div>
                      <p className="text-gray-400">Sector</p>
                      <p className="font-semibold">{companyInfo.sector}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Industry</p>
                      <p className="font-semibold">{companyInfo.industry}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Market Cap</p>
                      <p className="font-semibold">
                        {formatCurrency(companyInfo.market_cap)}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-400">P/E Ratio</p>
                      <p className="font-semibold">
                        {companyInfo.pe_ratio.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
            </div>

            {/* Chart Card */}
            <div className="lg:col-span-2">
                <div className="bg-gray-800 rounded-lg p-6">
                  <h3 className="text-xl font-semibold mb-4">Price History</h3>
                  <div className="h-[400px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={stockData}>
                        <defs>
                          <linearGradient
                            id="colorPrice"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="#2563eb"
                              stopOpacity={0.3}
                            />
                            <stop
                              offset="95%"
                              stopColor="#2563eb"
                              stopOpacity={0}
                            />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis
                          dataKey="date"
                          tick={{ fill: "#9CA3AF" }}
                          tickFormatter={(tick) => {
                            const date = new Date(tick);
                            return date.toLocaleDateString("en-IN", {
                              day: "2-digit",
                              month: "short",
                            });
                          }}
                        />
                        <YAxis
                          tick={{ fill: "#9CA3AF" }}
                          tickFormatter={(tick) => formatCurrency(tick)}
                          domain={["auto", "auto"]}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1F2937",
                            border: "1px solid #374151",
                            borderRadius: "0.5rem",
                          }}
                          labelStyle={{ color: "#9CA3AF" }}
                          formatter={(value: number) => [
                            formatCurrency(value),
                            "Price",
                          ]}
                          labelFormatter={(label) =>
                            new Date(label).toLocaleDateString("en-IN", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })
                          }
                        />
                        <Area
                          type="monotone"
                          dataKey="close"
                          stroke="#2563eb"
                          fillOpacity={1}
                          fill="url(#colorPrice)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
          </div>
        )}

        {/* Prediction Section */}
        {prediction && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gray-800 rounded-lg p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-semibold">
                    AI Prediction Results
                  </h3>
                  <Button
                    onClick={async () => {
                      try {
                        const token = localStorage.getItem("token");
                        if (!token) {
                          toast.error(
                            "You must be logged in to download reports"
                          );
                          return;
                        }

                        if (!prediction?.id) {
                          toast.error(
                            "No prediction available to generate report"
                          );
                          return;
                        }

                        const response = await axios.get(
                          `http://localhost:8000/reports/${prediction.id}/pdf`,
                          {
                            headers: {
                              Authorization: `Bearer ${token}`,
                            },
                            responseType: "blob",
                          }
                        );

                        // Create a URL for the blob
                        const url = window.URL.createObjectURL(
                          new Blob([response.data])
                        );
                        const link = document.createElement("a");
                        link.href = url;
                        link.setAttribute(
                          "download",
                          `${prediction.stock_symbol}_prediction_report.pdf`
                        );
                        document.body.appendChild(link);
                        link.click();
                        link.remove();
                        window.URL.revokeObjectURL(url);

                        toast.success("Report downloaded successfully");
                      } catch (error) {
                        console.error("Error downloading report:", error);
                        toast.error("Failed to download report");
                      }
                    }}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Download Report
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-gray-400 mb-1">Current Price</p>
                    <p className="text-2xl font-bold">
                      {formatCurrency(prediction.current_price)}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 mb-1">7-Day Prediction</p>
                    <p className="text-2xl font-bold">
                      {formatCurrency(prediction.predicted_price_7d)}
                    </p>
                    <p
                      className={`text-sm ${
                        prediction.predicted_price_7d > prediction.current_price
                          ? "text-green-500"
                          : "text-red-500"
                      }`}
                    >
                      {(
                        ((prediction.predicted_price_7d -
                          prediction.current_price) /
                          prediction.current_price) *
                        100
                      ).toFixed(2)}
                      % change
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 mb-1">30-Day Prediction</p>
                    <p className="text-2xl font-bold">
                      {formatCurrency(prediction.predicted_price_30d)}
                    </p>
                    <p
                      className={`text-sm ${
                        prediction.predicted_price_30d >
                        prediction.current_price
                          ? "text-green-500"
                          : "text-red-500"
                      }`}
                    >
                      {(
                        ((prediction.predicted_price_30d -
                          prediction.current_price) /
                          prediction.current_price) *
                        100
                      ).toFixed(2)}
                      % change
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 mb-1">AI Recommendation</p>
                    <p
                      className={`text-2xl font-bold ${getRecommendationClass(
                        prediction.recommendation
                      )}`}
                    >
                      {prediction.recommendation}
                    </p>
                    <div className="flex items-center">
                      <div className="w-full bg-secondary rounded-full h-1.5 mt-1 mb-1">
                        <div
                          className={`h-1.5 rounded-full ${
                            prediction.recommendation.toLowerCase() === "buy"
                              ? "bg-green-500"
                              : prediction.recommendation.toLowerCase() ===
                                "sell"
                              ? "bg-red-500"
                              : "bg-yellow-500"
                          }`}
                          style={{
                            width: `${prediction.confidence_level * 100}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-400">
                      Confidence:{" "}
                      {(prediction.confidence_level * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>
              </div>

              {/* Prediction History */}
              <div className="bg-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4">
                  Recent Predictions
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-gray-400 border-b border-gray-700">
                        <th className="pb-3">Stock</th>
                        <th className="pb-3">Price</th>
                        <th className="pb-3">7-Day</th>
                        <th className="pb-3">30-Day</th>
                        <th className="pb-3">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {predictionHistory.slice(0, 5).map((pred) => (
                        <tr key={pred.id} className="border-b border-gray-700">
                          <td className="py-3">{pred.stock_symbol}</td>
                          <td className="py-3">
                            {formatCurrency(pred.current_price)}
                          </td>
                          <td className="py-3">
                            {formatCurrency(pred.predicted_price_7d)}
                          </td>
                          <td className="py-3">
                            {formatCurrency(pred.predicted_price_30d)}
                          </td>
                          <td
                            className={`py-3 ${getRecommendationClass(
                              pred.recommendation
                            )}`}
                          >
                            {pred.recommendation}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
          </div>
        )}

          {/* No Predictions */}
          {/* Then just show prediction history */}
          {!companyInfo && !prediction && predictionHistory.length > 0 && (
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-semibold mb-4">Recent Predictions</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-gray-400 border-b border-gray-700">
                      <th className="pb-3">Stock</th>
                      <th className="pb-3">Price</th>
                      <th className="pb-3">7-Day</th>
                      <th className="pb-3">30-Day</th>
                      <th className="pb-3">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {predictionHistory.slice(0, 5).map((pred) => (
                      <tr key={pred.id} className="border-b border-gray-700">
                        <td className="py-3">{pred.stock_symbol}</td>
                        <td className="py-3">
                          {formatCurrency(pred.current_price)}
                        </td>
                        <td className="py-3">
                          {formatCurrency(pred.predicted_price_7d)}
                        </td>
                        <td className="py-3">
                          {formatCurrency(pred.predicted_price_30d)}
                        </td>
                        <td
                          className={`py-3 ${getRecommendationClass(
                            pred.recommendation
                          )}`}
                        >
                          {pred.recommendation}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
          </div>
        )}
          </div>
      </div>
    </div>
  );
};

export default Dashboard;
