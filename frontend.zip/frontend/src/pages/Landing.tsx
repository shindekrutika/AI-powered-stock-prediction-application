import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import {
  AreaChart,
  ArrowRight,
  BarChart3,
  LineChart,
  Lock,
  Search,
  TrendingUp,
} from "lucide-react";

export default function Index() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen pt-20 pb-16 flex items-center justify-center bg-hero-pattern overflow-hidden">
        <div className="absolute top-0 left-0 right-0 bottom-0 bg-gradient-radial from-blue-900/20 to-background z-0"></div>
        <div className="absolute w-96 h-96 bg-primary/20 rounded-full filter blur-[128px] top-1/4 right-1/4 animate-pulse-slow"></div>
        <div
          className="absolute w-80 h-80 bg-blue-700/20 rounded-full filter blur-[100px] bottom-1/4 left-1/4 animate-pulse-slow"
          style={{ animationDelay: "1s" }}
        ></div>

        <div className="container px-6 mx-auto relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight">
              Make Smarter Investment Decisions with{" "}
              <span className="text-gradient">AI-Powered</span> Stock
              Predictions
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              TrendWhisperer AI uses advanced machine learning algorithms to
              predict stock movements, helping you make data-driven investment
              decisions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => navigate("/signup")}
                className="hero-button bg-primary hover:bg-primary/90 text-white"
              >
                Get Started Free <ArrowRight size={16} className="ml-2" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="hero-button border-gray-600"
              >
                See How It Works
              </Button>
            </div>

            <div className="mt-12 p-4 bg-card-gradient backdrop-blur-sm border border-white/10 rounded-xl shadow-xl max-w-3xl mx-auto">
              <div className="aspect-video rounded-lg overflow-hidden bg-gray-900/50 flex items-center justify-center">
                <div className="text-center">
                  <LineChart size={64} className="mx-auto text-primary mb-4" />
                  <p className="text-gray-300">Interactive Demo Preview</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6 bg-background">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Powerful Features
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              TrendWhisperer AI combines cutting-edge technology with
              user-friendly design to deliver powerful investment tools.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="glass-card p-8 rounded-xl card-gradient-hover">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-6">
                <TrendingUp size={24} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">
                AI-Powered Predictions
              </h3>
              <p className="text-gray-400">
                Advanced machine learning algorithms analyze market patterns to
                forecast stock performance with high accuracy.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="glass-card p-8 rounded-xl card-gradient-hover">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-6">
                <BarChart3 size={24} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Interactive Charts</h3>
              <p className="text-gray-400">
                Visualize stock performance with interactive charts and
                customizable time frames for better analysis.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="glass-card p-8 rounded-xl card-gradient-hover">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-6">
                <Search size={24} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Stock Analysis</h3>
              <p className="text-gray-400">
                Get detailed company information, financial metrics, and
                industry comparisons for informed decisions.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="glass-card p-8 rounded-xl card-gradient-hover">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-6">
                <Lock size={24} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Secure Platform</h3>
              <p className="text-gray-400">
                End-to-end encryption and secure authentication protect your
                financial data and privacy.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="glass-card p-8 rounded-xl card-gradient-hover">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary"
                >
                  <path d="M6 9H4.5a2.5 2.5 0 0 0 0 5H6"></path>
                  <path d="M18 9h1.5a2.5 2.5 0 0 1 0 5H18"></path>
                  <path d="M8 9h8"></path>
                  <path d="M8 15h8"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">API Integration</h3>
              <p className="text-gray-400">
                Connect with popular trading platforms and financial services
                using our developer-friendly API.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="glass-card p-8 rounded-xl card-gradient-hover">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-6">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary"
                >
                  <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
                  <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
                  <line x1="6" y1="1" x2="6" y2="4"></line>
                  <line x1="10" y1="1" x2="10" y2="4"></line>
                  <line x1="14" y1="1" x2="14" y2="4"></line>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">PDF Reports</h3>
              <p className="text-gray-400">
                Download comprehensive analysis reports in PDF format for your
                records or to share with colleagues.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button
              onClick={() => navigate("/signup")}
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white"
            >
              Try TrendWhisperer AI Today
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-6 bg-muted">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What Our Users Say
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              Discover how TrendWhisperer AI has helped investors make smarter
              decisions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="glass-card p-8 rounded-xl">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center mr-3">
                  <span className="text-lg font-semibold">A</span>
                </div>
                <div>
                  <h4 className="font-semibold">Alex Thompson</h4>
                  <p className="text-sm text-gray-400">Day Trader</p>
                </div>
              </div>
              <p className="text-gray-300">
                "TrendWhisperer AI's predictions have been remarkably accurate.
                I've improved my trading success rate by over 30% since I
                started using it."
              </p>
            </div>

            {/* Testimonial 2 */}
            <div className="glass-card p-8 rounded-xl">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center mr-3">
                  <span className="text-lg font-semibold">S</span>
                </div>
                <div>
                  <h4 className="font-semibold">Sarah Chen</h4>
                  <p className="text-sm text-gray-400">Portfolio Manager</p>
                </div>
              </div>
              <p className="text-gray-300">
                "The detailed analysis and prediction reports save me hours of
                research time. This tool has become indispensable for my
                investment strategy."
              </p>
            </div>

            {/* Testimonial 3 */}
            <div className="glass-card p-8 rounded-xl">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center mr-3">
                  <span className="text-lg font-semibold">M</span>
                </div>
                <div>
                  <h4 className="font-semibold">Michael Johnson</h4>
                  <p className="text-sm text-gray-400">Retail Investor</p>
                </div>
              </div>
              <p className="text-gray-300">
                "As a newcomer to investing, TrendWhisperer AI has helped me
                make informed decisions that I wouldn't have been able to make
                on my own."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-accent relative overflow-hidden">
        <div className="absolute w-96 h-96 bg-primary/30 rounded-full filter blur-[150px] -top-20 -right-20"></div>
        <div className="container mx-auto relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Make Smarter Investment Decisions?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Join thousands of investors who are already leveraging the power
              of AI to improve their stock market returns.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => navigate("/signup")}
                className="hero-button bg-white text-accent-foreground hover:bg-gray-100"
              >
                Sign Up Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="hero-button border-white text-white hover:bg-white/10"
              >
                View Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-background border-t border-border">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <AreaChart className="text-white" size={24} />
                </div>
                <span className="text-lg font-bold text-white">
                  TrendWhisperer<span className="text-primary">AI</span>
                </span>
              </div>
              <p className="text-gray-400 mb-4">
                AI-powered stock predictions to help you make data-driven
                investment decisions.
              </p>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4">Product</h4>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Features
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Pricing
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    API
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Documentation
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4">Company</h4>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Careers
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Blog
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-lg mb-4">Legal</h4>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    Cookie Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-12 pt-8 text-center text-gray-500">
            <p>
              &copy; {new Date().getFullYear()} TrendWhisperer AI. All rights
              reserved.
            </p>
            <p className="mt-1 text-sm">
              Disclaimer: Stock predictions involve risk. Past performance is
              not indicative of future results.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
