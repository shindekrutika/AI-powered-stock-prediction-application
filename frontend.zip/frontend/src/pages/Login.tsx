import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import axios from "axios";
import { toast } from "sonner";

const API_URL = import.meta.env.VITE_BACKEND_URL;
if (!API_URL) {
  throw new Error("VITE_BACKEND_URL is not defined");
}

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const formData = new FormData();
      formData.append("username", email);
      formData.append("password", password);
      const response = await axios.post(`${API_URL}/auth/token`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      localStorage.setItem("token", response.data.access_token);
      toast.success("Login successful!");
      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 1000);
    } catch (err) {
      toast.error(err.response?.data?.detail || "Login failed");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <div className="flex flex-1 items-center justify-center px-6 py-12">
        <div className="w-full max-w-md relative">
          <div className="absolute w-80 h-80 bg-primary/20 rounded-full filter blur-[100px] -z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>

          <div className="glass-card border border-white/10 rounded-2xl p-8 shadow-xl backdrop-blur-lg">
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold">Welcome Back</h1>
              <p className="text-gray-400 mt-2">
                Log in to your TrendWhisperer AI account
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-300 mb-1"
                >
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="auth-input"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label
                    htmlFor="password"
                    className="block text-sm font-medium text-gray-300"
                  >
                    Password
                  </label>
                  <Link
                    to="#"
                    className="text-sm text-primary hover:text-primary/90"
                  >
                    Forgot password?
                  </Link>
                </div>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="auth-input"
                  required
                />
              </div>

              <div className="flex items-center">
                <input
                  id="remember-me"
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-600 bg-secondary text-primary focus:ring-primary"
                />
                <label
                  htmlFor="remember-me"
                  className="ml-2 block text-sm text-gray-300"
                >
                  Remember me
                </label>
              </div>

              <Button
                type="submit"
                className="auth-button bg-primary hover:bg-primary/90 text-white"
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "Log In"}
              </Button>

              <div className="text-center mt-4">
                <p className="text-gray-400 text-sm">
                  Don't have an account?{" "}
                  <Link
                    to="/signup"
                    className="text-primary hover:text-primary/90 font-medium"
                  >
                    Sign up
                  </Link>
                </p>
              </div>
            </form>

            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-700"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-card text-gray-400">
                    Or continue with
                  </span>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-4">
                <button className="flex justify-center items-center py-2.5 border border-gray-700 rounded-lg hover:bg-secondary transition-colors">
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path
                      fill="currentColor"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="currentColor"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="currentColor"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="currentColor"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  <span className="ml-2">Google</span>
                </button>
                <button className="flex justify-center items-center py-2.5 border border-gray-700 rounded-lg hover:bg-secondary transition-colors">
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M10 0.4C4.698 0.4 0.4 4.698 0.4 10C0.4 14.067 3.06 17.424 6.717 18.662C7.203 18.758 7.396 18.458 7.396 18.193C7.396 17.964 7.387 17.311 7.383 16.523C4.8 17.089 4.218 15.252 4.218 15.252C3.766 14.145 3.126 13.848 3.126 13.848C2.264 13.259 3.195 13.271 3.195 13.271C4.153 13.342 4.68 14.26 4.68 14.26C5.53 15.695 6.916 15.299 7.414 15.042C7.509 14.431 7.763 14.035 8.044 13.825C5.918 13.612 3.689 12.802 3.689 9.222C3.689 8.18 4.076 7.327 4.699 6.659C4.59 6.403 4.242 5.468 4.794 4.206C4.794 4.206 5.594 3.937 7.372 5.115C8.157 4.892 8.99 4.781 9.823 4.777C10.656 4.781 11.49 4.892 12.275 5.115C14.051 3.937 14.851 4.206 14.851 4.206C15.404 5.468 15.056 6.403 14.947 6.659C15.571 7.327 15.957 8.18 15.957 9.222C15.957 12.813 13.725 13.609 11.593 13.817C11.946 14.082 12.266 14.606 12.266 15.413C12.266 16.567 12.254 17.873 12.254 18.193C12.254 18.459 12.445 18.762 12.938 18.661C16.592 17.421 19.25 14.066 19.25 10C19.25 4.698 14.952 0.4 10 0.4z" />
                  </svg>
                  <span className="ml-2">GitHub</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
